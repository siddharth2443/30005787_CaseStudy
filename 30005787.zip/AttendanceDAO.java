import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AttendanceDAO {
    private Connection connection;

    public AttendanceDAO(Connection connection) {
        this.connection = connection;
    }

    //method to add attendance information for an employee
    public void recordAttendance(Attendance attendance) throws SQLException {
        String query = "INSERT INTO Attendance (employee_id, date, status) VALUES (?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, attendance.getEmployeeId());
            stmt.setDate(2, new java.sql.Date(attendance.getDate().getTime()));
            stmt.setString(3, attendance.getStatus());
            stmt.executeUpdate();
        }
    }

    //method to get attendance information of an employee using attendance id
    public Attendance getAttendance(int attendanceId) throws SQLException {
        String query = "SELECT * FROM Attendance WHERE attendance_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, attendanceId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Attendance(
                    rs.getInt("attendance_id"),
                    rs.getInt("employee_id"),
                    rs.getDate("date"),
                    rs.getString("status")
                );
            }
        }
        return null;
    }

    //method to update the attendance information of an employee
    public void updateAttendance(Attendance attendance) throws SQLException {
        String query = "UPDATE Attendance SET employee_id = ?, date = ?, status = ? WHERE attendance_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, attendance.getEmployeeId());
            stmt.setDate(2, new java.sql.Date(attendance.getDate().getTime()));
            stmt.setString(3, attendance.getStatus());
            stmt.setInt(4, attendance.getAttendanceId());
            stmt.executeUpdate();
        }
    }

    //method to delete attendance record of an employee from the database using attendance id
    public void deleteAttendance(int attendanceId) throws SQLException {
        String query = "DELETE FROM Attendance WHERE attendance_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, attendanceId);
            stmt.executeUpdate();
        }
    }

    //method to get attendance information by using employee id
    public List<Attendance> getAttendanceByEmployee(int employeeId) throws SQLException {
        List<Attendance> attendances = new ArrayList<>();
        String query = "SELECT * FROM Attendance WHERE employee_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                attendances.add(new Attendance(
                    rs.getInt("attendance_id"),
                    rs.getInt("employee_id"),
                    rs.getDate("date"),
                    rs.getString("status")
                ));
            }
        }
        return attendances;
    }

    //method to get attendance information by date
    public List<Attendance> getAttendanceByDate(Date date) throws SQLException {
        List<Attendance> attendances = new ArrayList<>();
        String query = "SELECT * FROM Attendance WHERE date = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setDate(1, new java.sql.Date(date.getTime()));
            ResultSet rs = stmt.executeQuery();
            while (rs.next()) {
                attendances.add(new Attendance(
                    rs.getInt("attendance_id"),
                    rs.getInt("employee_id"),
                    rs.getDate("date"),
                    rs.getString("status")
                ));
            }
        }
        return attendances;
    }
}

