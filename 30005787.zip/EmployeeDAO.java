import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {
    private Connection connection;

    public EmployeeDAO(Connection connection) {
        this.connection = connection;
    }

    //method to add new employee information to employee table
    public void addEmployee(Employee employee) throws SQLException {
        String query = "INSERT INTO Employee (name, department, email, phone_number) VALUES (?, ?, ?, ?)";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, employee.getName());
            stmt.setString(2, employee.getDepartment());
            stmt.setString(3, employee.getEmail());
            stmt.setString(4, employee.getPhoneNumber());
            stmt.executeUpdate();
        }
    }

    //method to get employee information from the database by using employee id
    public Employee getEmployee(int employeeId) throws SQLException {
        String query = "SELECT * FROM Employee WHERE employee_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                return new Employee(
                    rs.getInt("employee_id"),
                    rs.getString("name"),
                    rs.getString("department"),
                    rs.getString("email"),
                    rs.getString("phone_number")
                );
            }
        }
        return null;
    }

    //method to update the employee information in database 
    public void updateEmployee(Employee employee) throws SQLException {
        String query = "UPDATE Employee SET name = ?, department = ?, email = ?, phone_number = ? WHERE employee_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setString(1, employee.getName());
            stmt.setString(2, employee.getDepartment());
            stmt.setString(3, employee.getEmail());
            stmt.setString(4, employee.getPhoneNumber());
            stmt.setInt(5, employee.getEmployeeId());
            stmt.executeUpdate();
        }
    }

    //method to delete the employee from database using employee id
    public void deleteEmployee(int employeeId) throws SQLException {
        String query = "DELETE FROM Employee WHERE employee_id = ?";
        try (PreparedStatement stmt = connection.prepareStatement(query)) {
            stmt.setInt(1, employeeId);
            stmt.executeUpdate();
        }
    }

    //method to get information of all employees from the database
    public List<Employee> getAllEmployees() throws SQLException {
        List<Employee> employees = new ArrayList<>();
        String query = "SELECT * FROM Employee";
        try (Statement stmt = connection.createStatement()) {
            ResultSet rs = stmt.executeQuery(query);
            while (rs.next()) {
                employees.add(new Employee(
                    rs.getInt("employee_id"),
                    rs.getString("name"),
                    rs.getString("department"),
                    rs.getString("email"),
                    rs.getString("phone_number")
                ));
            }
        }
        return employees;
    }
}

