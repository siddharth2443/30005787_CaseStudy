import java.sql.*;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static Connection connection;

    public static void main(String[] args) {
        try {
        	
        	//making connection with local database named 'employee_db'
        	//replace database name, username and password with your own
            connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/employee_db", "root", "1234");
            EmployeeDAO employeeDAO = new EmployeeDAO(connection);
            AttendanceDAO attendanceDAO = new AttendanceDAO(connection);

            Scanner scanner = new Scanner(System.in);
            while (true) {
            	
            	//menu to perform different operations
                System.out.println("1. Add Employee");
                System.out.println("2. View Employee");
                System.out.println("3. Update Employee");
                System.out.println("4. Delete Employee");
                System.out.println("5. Record Attendance");
                System.out.println("6. View Attendance");
                System.out.println("7. Update Attendance");
                System.out.println("8. Delete Attendance");
                System.out.println("9. Generate Monthly Report");
                System.out.println("10. Generate Daily Report");
                System.out.println("11. Exit");
                System.out.print("Choose an option: ");
               
                //taking user input to perform different operations
                int choice = scanner.nextInt();

                
                //switch-case for each choice to perform operations
                switch (choice) {
                    case 1:
                        addEmployee(employeeDAO, scanner);
                        break;
                    case 2:
                        viewEmployee(employeeDAO, scanner);
                        break;
                    case 3:
                        updateEmployee(employeeDAO, scanner);
                        break;
                    case 4:
                        deleteEmployee(employeeDAO, scanner);
                        break;
                    case 5:
                        recordAttendance(attendanceDAO, scanner);
                        break;
                    case 6:
                        viewAttendance(attendanceDAO, scanner);
                        break;
                    case 7:
                        updateAttendance(attendanceDAO, scanner);
                        break;
                    case 8:
                        deleteAttendance(attendanceDAO, scanner);
                        break;
                    case 9:
                        generateMonthlyReport(attendanceDAO, scanner);
                        break;
                    case 10:
                        generateDailyReport(attendanceDAO, scanner);
                        break;
                    case 11:
                        System.out.println("Exiting...");
                        return;
                    default:
                        System.out.println("Invalid option. Try again.");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    //method to add new employee
    private static void addEmployee(EmployeeDAO employeeDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter name: ");
        String name = scanner.next();
        System.out.print("Enter department: ");
        String department = scanner.next();
        System.out.print("Enter email: ");
        String email = scanner.next();
        System.out.print("Enter phone number: ");
        String phoneNumber = scanner.next();

        Employee employee = new Employee();
        employee.setName(name);
        employee.setDepartment(department);
        employee.setEmail(email);
        employee.setPhoneNumber(phoneNumber);

        employeeDAO.addEmployee(employee);
        System.out.println("Employee added successfully.");
    }

    //method to view employee information
    private static void viewEmployee(EmployeeDAO employeeDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        Employee employee = employeeDAO.getEmployee(employeeId);
        if (employee != null) {
            System.out.println("ID: " + employee.getEmployeeId());
            System.out.println("Name: " + employee.getName());
            System.out.println("Department: " + employee.getDepartment());
            System.out.println("Email: " + employee.getEmail());
            System.out.println("Phone Number: " + employee.getPhoneNumber());
        } else {
            System.out.println("Employee not found.");
        }
    }

    //method to update employee information
    private static void updateEmployee(EmployeeDAO employeeDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        Employee employee = employeeDAO.getEmployee(employeeId);
        if (employee != null) {
            System.out.print("Enter new name: ");
            String name = scanner.next();
            System.out.print("Enter new department: ");
            String department = scanner.next();
            System.out.print("Enter new email: ");
            String email = scanner.next();
            System.out.print("Enter new phone number: ");
            String phoneNumber = scanner.next();

            employee.setName(name);
            employee.setDepartment(department);
            employee.setEmail(email);
            employee.setPhoneNumber(phoneNumber);

            employeeDAO.updateEmployee(employee);
            System.out.println("Employee updated successfully.");
        } else {
            System.out.println("Employee not found.");
        }
    }

    //method to delete employee information
    private static void deleteEmployee(EmployeeDAO employeeDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        employeeDAO.deleteEmployee(employeeId);
        System.out.println("Employee deleted successfully.");
    }

    //method to add attendance information for an employee
    private static void recordAttendance(AttendanceDAO attendanceDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        System.out.print("Enter date (yyyy-mm-dd): ");
        String dateString = scanner.next();
        System.out.print("Enter status (present/absent): ");
        String status = scanner.next();

        Attendance attendance = new Attendance();
        attendance.setEmployeeId(employeeId);
        attendance.setDate(Date.valueOf(dateString));
        attendance.setStatus(status);

        attendanceDAO.recordAttendance(attendance);
        System.out.println("Attendance recorded successfully.");
    }

    //method to view attendance of an employee by attendance id
    private static void viewAttendance(AttendanceDAO attendanceDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter attendance ID: ");
        int attendanceId = scanner.nextInt();
        Attendance attendance = attendanceDAO.getAttendance(attendanceId);
        if (attendance != null) {
            System.out.println("ID: " + attendance.getAttendanceId());
            System.out.println("Employee ID: " + attendance.getEmployeeId());
            System.out.println("Date: " + attendance.getDate());
            System.out.println("Status: " + attendance.getStatus());
        } else {
            System.out.println("Attendance record not found.");
        }
    }

    //method to update the attendance information of an employee
    private static void updateAttendance(AttendanceDAO attendanceDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter attendance ID: ");
        int attendanceId = scanner.nextInt();
        Attendance attendance = attendanceDAO.getAttendance(attendanceId);
        if (attendance != null) {
            System.out.print("Enter new employee ID: ");
            int employeeId = scanner.nextInt();
            System.out.print("Enter new date (yyyy-mm-dd): ");
            String dateString = scanner.next();
            System.out.print("Enter new status (present/absent): ");
            String status = scanner.next();

            attendance.setEmployeeId(employeeId);
            attendance.setDate(Date.valueOf(dateString));
            attendance.setStatus(status);

            attendanceDAO.updateAttendance(attendance);
            System.out.println("Attendance record updated successfully.");
        } else {
            System.out.println("Attendance record not found.");
        }
    }

    //method to delete attendance record for an employee
    private static void deleteAttendance(AttendanceDAO attendanceDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter attendance ID: ");
        int attendanceId = scanner.nextInt();
        attendanceDAO.deleteAttendance(attendanceId);
        System.out.println("Attendance record deleted successfully.");
    }

    //method to generate monthly report of attendance
    private static void generateMonthlyReport(AttendanceDAO attendanceDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter employee ID: ");
        int employeeId = scanner.nextInt();
        System.out.print("Enter month (1-12): ");
        int month = scanner.nextInt();

        List<Attendance> attendances = attendanceDAO.getAttendanceByEmployee(employeeId);
        System.out.println("Attendance report for employee ID " + employeeId + " for month " + month + ":");
        for (Attendance attendance : attendances) {
            if (attendance.getDate().toLocalDate().getMonthValue() == month) {
                System.out.println(attendance.getDate() + " - " + attendance.getStatus());
            }
        }
    }

    //method to generate daily attendance report
    private static void generateDailyReport(AttendanceDAO attendanceDAO, Scanner scanner) throws SQLException {
        System.out.print("Enter date (yyyy-mm-dd): ");
        String dateString = scanner.next();
        Date date = Date.valueOf(dateString);

        List<Attendance> attendances = attendanceDAO.getAttendanceByDate(date);
        System.out.println("Attendance report for date " + date + ":");
        for (Attendance attendance : attendances) {
            System.out.println("Employee ID: " + attendance.getEmployeeId() + " - " + attendance.getStatus());
        }
    }
}
